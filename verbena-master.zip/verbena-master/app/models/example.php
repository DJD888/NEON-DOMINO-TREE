<?php

/**
 * VERBENA FRAMEWORK
 * 2015 - MIT LICENSE.
 */

namespace App\Models;

use Bootstrap\Models\Model;
use Bootstrap\Database\Factory;

class Example extends Model {

    protected static $db;

    /**
     * Example
     *
     * @access  public
     * @param   void
     * @return  array
     */
    public static function example_method() {


    }

}