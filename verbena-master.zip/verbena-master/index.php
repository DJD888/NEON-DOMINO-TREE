<?php

/**
 * VERBENA FRAMEWORK
 * 2015 - MIT LICENSE.
 */

$_abs_path  = dirname(realpath(__FILE__));
include dirname(realpath(__FILE__)) . '/bootstrap/autoload.php';
